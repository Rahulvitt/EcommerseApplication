package com.ecom.app.service;

import com.ecom.app.controller.model.User;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Service
public class UserService {
    private List<User> list = new ArrayList<>();
   private  Long userid = 1L ;

    public List<User> getAllUsers(){
        return list;
    }

    public void addUser(User user){
        user.setId(userid++);
        list.add(user);
    }


    public User fetchUser(Long id) {
       for(User user : list){
           if(user.getId().equals(id)){
             return user;
           }
       }
       return null;
    }
}
