package com.ecom.app.controller;

import com.ecom.app.controller.model.User;

import com.ecom.app.service.UserService;

import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class UserController {

   private final UserService userService;

   @GetMapping("/users")
   public ResponseEntity<List<User>> getAllUsers(){
     return ResponseEntity .ok(userService.getAllUsers());
   }

   @PostMapping("/create")
    private String createUser(@RequestBody User user){
       userService.addUser(user);
       return "successfully created ";
   }
   @GetMapping("/singleuser/{id}")
    private User getSingleUser(@PathVariable Long id){
       return (User) userService.fetchUser(id);
   }
}
