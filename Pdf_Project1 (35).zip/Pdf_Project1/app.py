import os
import time
import hashlib
import streamlit as st
from PyPDF2 import PdfReader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.chains.question_answering import load_qa_chain
from langchain_google_genai import ChatGoogleGenerativeAI
# Note: OpenAI callback not available for Google API
import asyncio
import threading
from functools import lru_cache
from typing import Optional, List, Dict, Any
import logging

# Load environment variables. This should be done at the very beginning.
from dotenv import load_dotenv
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Performance configuration
RATE_LIMIT_DELAY = 0.05  # Reduced to 50ms for better performance
MAX_CHUNKS_PER_BATCH = 20  # Increased batch size
MAX_FILE_SIZE_MB = 50  # Maximum file size to process
CACHE_TTL = 3600  # Cache TTL in seconds

# Initialize session state keys
SESSION_KEYS = {
    'vector_store': None,
    'pdf_processed': False,
    'current_pdf_hash': None,
    'embeddings_model': None,
    'llm_model': None,
    'processing_progress': 0,
    'last_processed_time': None,
    'chat_history': [],
    'current_pdf_name': None
}

@lru_cache(maxsize=128)
def get_file_hash(file_content: bytes) -> str:
    """Generate a hash for file content to detect changes."""
    return hashlib.md5(file_content).hexdigest()

@lru_cache(maxsize=1)
def get_embeddings_model(api_key: str):
    """Cache the embeddings model to avoid recreating it."""
    return GoogleGenerativeAIEmbeddings(
        google_api_key=api_key, 
        model="models/embedding-001"
    )

@lru_cache(maxsize=1)
def get_llm_model(api_key: str):
    """Cache the LLM model to avoid recreating it."""
    return ChatGoogleGenerativeAI(
        google_api_key=api_key, 
        model="gemini-1.5-flash",
        temperature=0.7,
        max_output_tokens=800  # Reduced for lower cost
    )

def rate_limited_request(func, delay=RATE_LIMIT_DELAY):
    """Helper function to add rate limiting to API requests."""
    time.sleep(delay)
    return func()

def retry_request(func, retries=3, delay=5):
    """Optimized retry function with exponential backoff."""
    for attempt in range(retries):
        try:
            return rate_limited_request(func)
        except Exception as e:
            error_str = str(e).lower()
            if any(error_type in error_str for error_type in 
                   ['ratelimiterror', 'rate_limit', 'too_many_requests', 'quota_exceeded']):
                wait_time = min(delay * (2 ** attempt), 30)
                st.warning(f"Rate limit exceeded. Retrying in {wait_time}s... (Attempt {attempt + 1}/{retries})")
                time.sleep(wait_time)
            else:
                logger.error(f"Non-retryable error: {str(e)}")
                st.error(f"Error occurred: {str(e)}")
                return None
    st.error("Max retries exceeded. Please try again later.")
    return None

async def process_chunks_async(chunks: List[str], embeddings_model, batch_size: int = MAX_CHUNKS_PER_BATCH):
    """Process text chunks asynchronously for better performance."""
    all_embeddings = []
    total_batches = (len(chunks) + batch_size - 1) // batch_size
    
    for i in range(0, len(chunks), batch_size):
        batch = chunks[i:i + batch_size]
        try:
            batch_embeddings = embeddings_model.embed_documents(batch)
            all_embeddings.extend(batch_embeddings)
            
            # Update progress
            current_batch = (i // batch_size) + 1
            progress = (current_batch / total_batches) * 100
            st.session_state.processing_progress = progress
            
            # Small delay between batches
            await asyncio.sleep(RATE_LIMIT_DELAY)
            
        except Exception as e:
            logger.error(f"Error processing batch {i//batch_size + 1}: {str(e)}")
            raise
    
    return all_embeddings

def optimize_text_chunks(text: str) -> List[str]:
    """Optimized text chunking with better parameters."""
    # Remove excessive whitespace and normalize text
    text = ' '.join(text.split())
    
    # Use RecursiveCharacterTextSplitter for better chunking
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,  # Reduced chunk size for lower token usage
        chunk_overlap=100,  # Reduced overlap for efficiency
        length_function=len,
        separators=["\n\n", "\n", ". ", " ", ""]  # Better separators
    )
    
    chunks = text_splitter.split_text(text)
    
    # Filter out very short chunks
    chunks = [chunk.strip() for chunk in chunks if len(chunk.strip()) > 50]
    
    return chunks

def initialize_session_state():
    """Initialize all session state variables efficiently."""
    for key, default_value in SESSION_KEYS.items():
        if key not in st.session_state:
            st.session_state[key] = default_value

def cleanup_session_state():
    """Clean up session state to free memory."""
    keys_to_remove = ['processing_progress']
    for key in keys_to_remove:
        if key in st.session_state:
            del st.session_state[key]

def add_message_to_chat(role: str, content: str, timestamp=None):
    """Add a message to the chat history."""
    if timestamp is None:
        from datetime import datetime
        timestamp = datetime.now()
    
    message = {
        'role': role,
        'content': content,
        'timestamp': timestamp
    }
    
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []
    
    st.session_state.chat_history.append(message)

def clear_chat_history():
    """Clear the chat history."""
    st.session_state.chat_history = []

def validate_pdf_file(pdf_file) -> bool:
    """Validate PDF file before processing."""
    if pdf_file is None:
        return False
    
    # Check file size
    file_size_mb = len(pdf_file.getvalue()) / (1024 * 1024)
    if file_size_mb > MAX_FILE_SIZE_MB:
        st.error(f"File too large ({file_size_mb:.1f}MB). Maximum size is {MAX_FILE_SIZE_MB}MB.")
        return False
    
    return True

async def process_pdf_async(pdf_file, api_key: str):
    """Async PDF processing function."""
    try:
        # Read PDF file
        reader = PdfReader(pdf_file)
        text = ""
        
        # Progress bar for PDF reading
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        for i, page in enumerate(reader.pages):
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
            
            # Update progress
            progress = (i + 1) / len(reader.pages)
            progress_bar.progress(progress)
            status_text.text(f"Reading page {i + 1} of {len(reader.pages)}")
        
        progress_bar.empty()
        status_text.empty()
        
        if not text.strip():
            st.error("No text could be extracted from the PDF.")
            return None
        
        # Optimize text chunks
        chunks = optimize_text_chunks(text)
        st.info(f"Created {len(chunks)} optimized text chunks")
        
        # Get cached embeddings model
        embeddings_model = get_embeddings_model(api_key)
        
        # Process embeddings asynchronously
        all_embeddings = await process_chunks_async(chunks, embeddings_model)
        
        # Create vector store
        vector_store = FAISS.from_embeddings(
            text_embeddings=list(zip(chunks, all_embeddings)),
            embedding=embeddings_model
        )
        
        return vector_store
        
    except Exception as e:
        logger.error(f"Error processing PDF: {str(e)}")
        st.error(f"Error processing PDF: {str(e)}")
        return None

def display_chat_message(message: Dict):
    """Display a single chat message with proper styling."""
    role = message['role']
    content = message['content']
    timestamp = message['timestamp']
    
    # Format timestamp
    time_str = timestamp.strftime("%H:%M")
    
    if role == "user":
        # User message styling - simplified
        st.markdown(f"""
        <div style="
            background-color: #e3f2fd;
            padding: 8px 12px;
            border-radius: 12px;
            margin: 8px 0;
            max-width: 70%;
            margin-left: auto;
            font-size: 14px;
        ">
            <div style="color: #333;">
                {content}
            </div>
            <div style="font-size: 11px; color: #666; text-align: right; margin-top: 4px;">
                {time_str}
            </div>
        </div>
        """, unsafe_allow_html=True)
    else:
        # AI message styling - simplified
        st.markdown(f"""
        <div style="
            background-color: #f5f5f5;
            padding: 8px 12px;
            border-radius: 12px;
            margin: 8px 0;
            max-width: 70%;
            font-size: 14px;
        ">
            <div style="color: #333;">
                {content}
            </div>
            <div style="font-size: 11px; color: #666; margin-top: 4px;">
                {time_str}
            </div>
        </div>
        """, unsafe_allow_html=True)

def display_chat_history():
    """Display the entire chat history."""
    if 'chat_history' in st.session_state and st.session_state.chat_history:
        # Simple container for chat messages
        chat_container = st.container()
        with chat_container:
            for message in st.session_state.chat_history:
                display_chat_message(message)

def create_chat_input():
    """Create the chat input interface."""
    # Simple input with single button
    user_input = st.text_area(
        "Ask a question:",
        placeholder="Type your question here...",
        height=80,
        key="chat_input"
    )
    
    col1, col2, col3 = st.columns([1, 1, 3])
    with col1:
        submit_button = st.button("Ask Question", type="primary")
    
    return user_input, submit_button

def clear_chat_input():
    """Clear the chat input field."""
    if 'chat_input' in st.session_state:
        del st.session_state.chat_input

def main():
    """
    Optimized main function with simplified chat-like UI structure.
    """
    # Get API key
    google_api_key = os.getenv("GOOGLE_API_KEY")
    
    if not google_api_key:
        st.error("Google API key not found. Please set the GOOGLE_API_KEY environment variable.")
        return

    # Page configuration - narrow layout
    st.set_page_config(
        page_title="PDF Chat Assistant",
        page_icon="📚",
        layout="centered"
    )

    st.title("📚 PDF Chat Assistant")

    # Initialize session state
    initialize_session_state()

    # PDF Upload Section - simplified
    pdf_file = st.file_uploader(
        "Upload PDF", 
        type="pdf",
        help=f"Max size: {MAX_FILE_SIZE_MB}MB"
    )

    if not validate_pdf_file(pdf_file):
        return

    # Check if this is a new PDF file
    if pdf_file is not None:
        file_content = pdf_file.getvalue()
        current_file_hash = get_file_hash(file_content)
        
        # Update PDF name
        st.session_state.current_pdf_name = pdf_file.name
        
        if (st.session_state.current_pdf_hash != current_file_hash or 
            not st.session_state.pdf_processed):
            
            st.session_state.current_pdf_hash = current_file_hash
            st.session_state.pdf_processed = False
            
            # Clear chat history when new PDF is uploaded
            clear_chat_history()
            
            with st.spinner("Processing PDF..."):
                # Process PDF asynchronously
                vector_store = asyncio.run(process_pdf_async(pdf_file, google_api_key))
                
                if vector_store is not None:
                    st.session_state.vector_store = vector_store
                    st.session_state.pdf_processed = True
                    st.session_state.last_processed_time = time.time()
                    cleanup_session_state()
                    
                    # Add welcome message to chat
                    add_message_to_chat(
                        "assistant", 
                        f"Hello! I've processed your PDF. You can now ask me questions about it!"
                    )
                else:
                    return

    # Chat Section - simplified
    if st.session_state.pdf_processed:
        # Display chat history
        display_chat_history()
        
        # Chat input
        user_input, submit_button = create_chat_input()

        # Process question
        if submit_button and user_input.strip() and st.session_state.vector_store is not None:
            # Add user message to chat
            add_message_to_chat("user", user_input.strip())
            
            with st.spinner("Thinking..."):
                try:
                    # Get cached LLM model
                    llm_model = get_llm_model(google_api_key)
                    
                    # Perform similarity search
                    search_results = st.session_state.vector_store.similarity_search(
                        user_input.strip(), 
                        k=3  # Reduced from 4 to use fewer tokens
                    )

                    # Load QA chain (this is lightweight, no need to cache)
                    qa_chain = load_qa_chain(llm_model, chain_type="stuff", verbose=False)

                    # Generate response
                    result = retry_request(
                        lambda: qa_chain.invoke({
                            "input_documents": search_results, 
                            "question": user_input.strip()
                        })
                    )
                    
                    if result is None:
                        add_message_to_chat("assistant", "Sorry, I encountered an error while processing your question. Please try again.")
                        return

                    # Extract the response from the result
                    if isinstance(result, dict):
                        # For Google Generative AI with LangChain, the response is typically in 'output_text'
                        response = result.get('output_text', result.get('text', result.get('result', result.get('output', ''))))
                        if not response:
                            # If no text found, try to get the full result as string
                            response = str(result)
                        # Debug: Log the result structure for troubleshooting
                        logger.info(f"Result structure: {list(result.keys()) if isinstance(result, dict) else type(result)}")
                    else:
                        response = str(result)

                    # Add AI response to chat
                    add_message_to_chat("assistant", response)
                    
                    # Clear the input field
                    clear_chat_input()
                    
                    # Rerun to show updated chat
                    st.rerun()
                    
                except Exception as e:
                    logger.error(f"Error generating response: {str(e)}")
                    error_message = f"Sorry, I encountered an error: {str(e)}"
                    add_message_to_chat("assistant", error_message)
                    
                    # Clear the input field
                    clear_chat_input()
                    
                    st.rerun()
    
    else:
        st.info("Upload a PDF to start chatting!")

if __name__ == '__main__':
    main()
