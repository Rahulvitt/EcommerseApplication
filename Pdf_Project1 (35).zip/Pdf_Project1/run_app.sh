#!/bin/bash

# PDF Summarizer QnA Bot Runner Script
# This script activates the virtual environment and runs the Streamlit app

echo "🚀 Starting PDF Summarizer QnA Bot..."

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "❌ Virtual environment not found. Please run setup first."
    exit 1
fi

# Activate virtual environment
echo "📦 Activating virtual environment..."
source venv/bin/activate

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo "⚠️  Warning: .env file not found. Please create one with your Google API key."
    echo "   Example: echo 'GOOGLE_API_KEY=your_api_key_here' > .env"
fi

# Run the Streamlit app
echo "🌐 Starting Streamlit application..."
echo "📱 The app will open in your browser at http://localhost:8501"
echo "🛑 Press Ctrl+C to stop the application"
echo ""

streamlit run app.py
